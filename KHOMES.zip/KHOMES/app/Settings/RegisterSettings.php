<?php

namespace App\Settings;

use Spatie\LaravelSettings\Settings;

class RegisterSettings extends Settings
{
    public ?array $domains = [];

    public ?array $codes = [];

    public ?string $haravanApiToken;

    public ?string $emailIsNotInOrg;

    public ?string $emailIsExists;

    public ?string $registerSuccess;

    public ?string $codeIsNotValid;

    public static function group(): string
    {
        return 'register';
    }
}
