<?php

namespace App\Filament\Pages;

use App\Settings\RegisterSettings;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Pages\SettingsPage;

class Registration extends SettingsPage
{
    protected static ?string $navigationIcon = 'heroicon-o-cog-6-tooth';

    protected static string $settings = RegisterSettings::class;

    protected static ?string $navigationLabel = 'Settings';

    protected static ?int $navigationSort = 2;

    protected static ?string $navigationGroup = 'Customers';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('Haravan API')
                    ->schema([
                        TextInput::make('haravanApiToken')
                            ->label('API Token')
                            ->required(),
                    ]),
                Section::make('Allowed Domains')
                    ->description('Domains that are allowed to register new users.')
                    ->schema([
                        Repeater::make('domains')
                            ->label('')
                            ->addActionLabel('Add Domain')
                            ->schema([
                                TextInput::make('domain')
                                    ->placeholder('example.com')
                                    ->required(),
                                TextInput::make('tags')
                                    ->placeholder('tag1,tag2,...')
                                    ->required(),
                            ])
                            ->columns(),
                    ]),
                Section::make('Approved Codes')
                    ->description('Approved codes.')
                    ->schema([
                        Repeater::make('codes')
                            ->label('')
                            ->addActionLabel('Add Code')
                            ->schema([
                                TextInput::make('code')
                                    ->placeholder('KHOMES')
                                    ->required(),
                            ])
                            ->columns(4),
                    ]),
                Section::make('Messages')
                    ->description('Messages that are displayed to users.')
                    ->schema([
                        TextInput::make('emailIsNotInOrg')
                            ->label('Email is not in organization')
                            ->default('Email không thuộc tổ chức được đăng ký. Vui lòng kiểm tra lại hoặc liên hệ bộ phận hỗ trợ!')
                            ->required(),
                        TextInput::make('emailIsExists')
                            ->label('Email is existing')
                            ->default('Email đã được đăng ký, vui lòng kiểm tra lại hoặc liên hệ bộ phận hỗ trợ!')
                            ->required(),
                        TextInput::make('registerSuccess')
                            ->label('Register success')
                            ->default('Chúc mừng bạn đã đăng ký tài khoản thành công. Vui lòng kiểm tra email để kích hoạt tài khoản!')
                            ->required(),
                        TextInput::make('codeIsNotValid')
                            ->label('Code is not valid')
                            ->default('Mã đăng ký không hợp lệ. Vui lòng kiểm tra lại hoặc liên hệ bộ phận hỗ trợ!')
                            ->required(),
                    ]),
            ]);
    }
}
