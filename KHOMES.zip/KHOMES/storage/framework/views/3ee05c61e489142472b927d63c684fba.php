<p
    <?php echo e($attributes->class(['fi-section-header-description overflow-hidden break-words text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /Volumes/960GB/PROJECTS/KHOMES/vendor/filament/support/src/../resources/views/components/section/description.blade.php ENDPATH**/ ?>