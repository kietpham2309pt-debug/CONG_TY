<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Livewire\Volt\Component;
use App\Models\Customer;
use App\Settings\RegisterSettings;

?>

<section class="mx-auto container p-4">
    <form wire:submit="submit">
        <div class="grid grid-cols-2 gap-2 ">
            <h4 class="font-semibold text-lg text-start">Dành cho nhân viên</h4>
            <span class="pl-2 text-gray-700 text-start">Đăng ký để nhận ưu đãi Hot</span>
            <div class="w-full px-2 mb-4 flex flex-col items-start justify-start">
                <label class="pl-3 pb-2 text-gray-500">Họ và tên (*)</label>
                <input wire:model="name"
                    class="py-1.5 px-4 w-full bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none"
                    type="text">
                <div class="text-red-500 text-sm mt-1">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
            <div class="w-full px-2 mb-4  flex flex-col items-start justify-start">
                <label class="pl-2 pb-2 text-gray-500">Email (*)</label>
                <input wire:model="email"
                    class="py-1.5 px-4 w-full bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none"
                    type="text">
                <div class="text-red-500 text-sm mt-1">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            <div class="w-full px-2 mb-4 flex flex-col items-start justify-start">
                <label class="pl-2 pb-2 text-gray-500">Số điện thoại (*)</label>
                <input wire:model="phone"
                    class="py-1.5 px-4 w-full bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none"
                    type="text">
                <div class="text-red-500 text-sm mt-1">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
            <div class="w-full px-2 mb-4 flex flex-col items-start justify-start">
                <label class="pl-2 pb-2 text-gray-500">Ngày sinh (*)</label>
                <input wire:model="birthday"
                    class="py-1.5 px-4 w-full bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none"
                    type="date">
                <div class="text-red-500 text-sm mt-1">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
            <div class="flex items-center col-span-2 mb-4">
                <label class="pl-5 text-gray-500 w-1/2 text-start">Giới tính (*)</label>
                <div class="w-1/2 pl-3">
                    <select id="location" name="location" class="py-1.5 bg-gray-200 rounded-md px-4"
                        wire:model="gender">
                        <option value="1" selected>Nam</option>
                        <option value="0">Nữ</option>
                    </select>
                    <div class="text-red-500 text-sm mt-1">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
            <div class="flex items-center col-span-2 mb-4">
                <label class="pl-5 text-gray-500 w-1/2 text-start">Mã đăng ký (nếu có)</label>
                <div class="w-1/2 pl-3">
                    <input wire:model="code"
                        class="py-1.5 px-4 w-1/2 bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none"
                        type="text">
                    <div class="text-red-500 text-sm mt-1">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
        </div>
        <!--[if BLOCK]><![endif]--><?php if($message): ?>
            <div
                class="relative w-full rounded-lg border border-transparent bg-green-50 p-4 [&>svg]:absolute [&>svg]:text-foreground [&>svg]:left-4 [&>svg]:top-4 [&>svg+div]:translate-y-[-3px] [&:has(svg)]:pl-11 text-green-600">
                <svg class="w-5 h-5 -translate-y-0.5" xmlns="http://www.w3.org/2000/svg" fill="none"
                    viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div class="text-sm opacity-80"><?php echo e($message); ?></div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($messageAfterValidation): ?>
            <div
                class="relative w-full rounded-lg border border-transparent bg-red-50 p-4 [&>svg]:absolute [&>svg]:text-foreground [&>svg]:left-4 [&>svg]:top-4 [&>svg+div]:translate-y-[-3px] [&:has(svg)]:pl-11 text-red-600">
                <svg class="w-5 h-5 -translate-y-0.5" xmlns="http://www.w3.org/2000/svg" fill="none"
                    viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
                </svg>
                <div class="text-sm opacity-80"><?php echo e($messageAfterValidation); ?></div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <button class="flex w-fit px-6 py-2 mt-4 text-white rounded-xl bg-[#203354] mx-auto"
            wire:loading.class="disabled" wire:loading.class.remove="bg-[#203354]" wire:loading.attr="disabled">
            <div wire:loading>
                <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <style>
                        .spinner_EUy1 {
                            animation: spinner_grm3 1.2s infinite
                        }

                        .spinner_f6oS {
                            animation-delay: .1s
                        }

                        .spinner_g3nX {
                            animation-delay: .2s
                        }

                        .spinner_nvEs {
                            animation-delay: .3s
                        }

                        .spinner_MaNM {
                            animation-delay: .4s
                        }

                        .spinner_4nle {
                            animation-delay: .5s
                        }

                        .spinner_ZETM {
                            animation-delay: .6s
                        }

                        .spinner_HXuO {
                            animation-delay: .7s
                        }

                        .spinner_YaQo {
                            animation-delay: .8s
                        }

                        .spinner_GOx1 {
                            animation-delay: .9s
                        }

                        .spinner_4vv9 {
                            animation-delay: 1s
                        }

                        .spinner_NTs9 {
                            animation-delay: 1.1s
                        }

                        .spinner_auJJ {
                            transform-origin: center;
                            animation: spinner_T3O6 6s linear infinite
                        }

                        @keyframes spinner_grm3 {

                            0%,
                            50% {
                                animation-timing-function: cubic-bezier(.27, .42, .37, .99);
                                r: 1px
                            }

                            25% {
                                animation-timing-function: cubic-bezier(.53, 0, .61, .73);
                                r: 2px
                            }
                        }

                        @keyframes spinner_T3O6 {
                            0% {
                                transform: rotate(360deg)
                            }

                            100% {
                                transform: rotate(0deg)
                            }
                        }
                    </style>
                    <g class="spinner_auJJ">
                        <circle class="spinner_EUy1" cx="12" cy="3" r="1" />
                        <circle class="spinner_EUy1 spinner_f6oS" cx="16.50" cy="4.21" r="1" />
                        <circle class="spinner_EUy1 spinner_NTs9" cx="7.50" cy="4.21" r="1" />
                        <circle class="spinner_EUy1 spinner_g3nX" cx="19.79" cy="7.50" r="1" />
                        <circle class="spinner_EUy1 spinner_4vv9" cx="4.21" cy="7.50" r="1" />
                        <circle class="spinner_EUy1 spinner_nvEs" cx="21.00" cy="12.00" r="1" />
                        <circle class="spinner_EUy1 spinner_GOx1" cx="3.00" cy="12.00" r="1" />
                        <circle class="spinner_EUy1 spinner_MaNM" cx="19.79" cy="16.50" r="1" />
                        <circle class="spinner_EUy1 spinner_YaQo" cx="4.21" cy="16.50" r="1" />
                        <circle class="spinner_EUy1 spinner_4nle" cx="16.50" cy="19.79" r="1" />
                        <circle class="spinner_EUy1 spinner_HXuO" cx="7.50" cy="19.79" r="1" />
                        <circle class="spinner_EUy1 spinner_ZETM" cx="12" cy="21" r="1" />
                    </g>
                </svg>
            </div>
            <span wire:loading.class="hidden">ĐĂNG KÝ</span>
        </button>
    </form>
</section><?php /**PATH /Volumes/960GB/PROJECTS/KHOMES/resources/views/livewire/register.blade.php ENDPATH**/ ?>