<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Livewire\Volt\Component;
use App\Models\Customer;
use App\Settings\RegisterSettings;

new class extends Component {
    public string $name = '';
    public string $email = '';
    //    public string $password = '';
    //    public string $password_confirmation = '';
    //    public bool $isShowPassword = false;
    //    public bool $isShowPasswordConfirmation = false;

    public string $phone = '';
    public string $birthday = '';
    public string $gender = '1';
    public string $code = '';

    public string $message = '';
    public string $messageAfterValidation = '';

    public function submit(Request $request): void
    {
        $this->message = '';
        $this->messageAfterValidation = '';

        $validated = $this->validate([
            'name' => 'required|string|min:2',
            'email' => 'required|email|unique:customers,email',
            //            'password' => 'required|string|min:6|confirmed',
            'phone' => 'required|numeric|digits:10|unique:customers,phone',
            'birthday' => 'required|date',
            'gender' => 'required|in:0,1',
            'code' => 'nullable|string',
        ]);

        // Check email suffix by domain
        $haravan = app(RegisterSettings::class);
        $isEmailFromDomain = false;
        $isCodeValid = false;
        $isPassedRegisterConditions = false;

        foreach ($haravan->domains as $domain) {
            if (str_ends_with($validated['email'], '@' . $domain['domain'])) {
                $isEmailFromDomain = true;
                $isPassedRegisterConditions = true;
                $validated['tags'] = $domain['tags'] ?? '';
                break;
            }
        }

        if (!$isEmailFromDomain) {
            // Check for code condition
            foreach ($haravan->codes as $code) {
                if (strtolower($this->code) === strtolower($code['code'])) {
                    $isCodeValid = true;
                    $isPassedRegisterConditions = true;
                    $validated['tags'] = $code['code'];
                    break;
                }
            }
        }

        if (!$isPassedRegisterConditions) {
            if (!$isCodeValid && !empty($this->code)) {
                $this->addError('code', $haravan->codeIsNotValid);
                return;
            }

            $this->addError('email', $haravan->emailIsNotInOrg);
            return;
        }

        $canRegister = $this->canRegisterCustomerHaravan($validated['email'], $haravan->haravanApiToken);

        if (!$canRegister) {
            $this->addError('email', $haravan->emailIsExists);
            return;
        }

        $created = (object) $this->createCustomerHaravan($validated, $haravan->haravanApiToken);

        if ($created->success) {
            $this->message = $haravan->registerSuccess;

            //            Customer::create(collect($validated)->except('password', 'password_confirmation', 'tags')->toArray());
            Customer::create(collect($validated)->except('tags', 'code')->toArray());
        }

        if (!$created->success) {
            $this->messageAfterValidation = $created->message;
        }
    }

    protected function createCustomerHaravan(array $data, $haravanApiToken): array
    {
        $randomPassword = 'corporateoffers.com.vn';

        $response = Http::asJson()
            ->withToken($haravanApiToken)
            ->post('https://apis.haravan.com/com/customers.json', [
                'customer' => [
                    'first_name' => $data['name'],
                    'last_name' => '',
                    'email' => $data['email'],
                    'phone' => $data['phone'],
                    'birthday' => $data['birthday'],
                    'gender' => $data['gender'],
                    //                    'password' => $data['password'],
                    //                    'password_confirmation' => $data['password'],
                    'verified_email' => true,
                    'send_email_invite' => true,
                    'send_email_welcome' => false,
                    'tags' => $data['tags'],
                ],
            ])
            ->json();

        // null
        if (!$response) {
            return [
                'success' => false,
                'message' => 'Không thể tại tào khoản trên hệ thống!',
            ];
        }

        // errors data
        if (isset($response['errors'])) {
            return [
                'success' => false,
                'message' => $response['errors'],
            ];
        }

        // created: single customer object
        if (!empty($response['customer'])) {
            return [
                'success' => true,
            ];
        }
    }

    protected function canRegisterCustomerHaravan(string $email, $haravanApiToken): bool
    {
        $response = Http::withToken($haravanApiToken)
            ->get('https://apis.haravan.com/com/customers/search.json', [
                'query' => $email,
            ])
            ->json();

        // null
        if (!$response) {
            return false;
        }

        // no customer yet, return "customers" array
        if (isset($response['customers']) && count($response['customers']) === 0) {
            return true;
        }

        return false;
    }
}; ?>
<section class="mx-auto container p-4">
    <form wire:submit="submit">
        <div class="grid grid-cols-2 gap-2 ">
            <h4 class="font-semibold text-lg text-start">Dành cho nhân viên</h4>
            <span class="pl-2 text-gray-700 text-start">Đăng ký để nhận ưu đãi Hot</span>
            <div class="w-full px-2 mb-4 flex flex-col items-start justify-start">
                <label class="pl-3 pb-2 text-gray-500">Họ và tên (*)</label>
                <input wire:model="name"
                    class="py-1.5 px-4 w-full bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none"
                    type="text">
                <div class="text-red-500 text-sm mt-1">
                    @error('name')
                        {{ $message }}
                    @enderror
                </div>
            </div>
            <div class="w-full px-2 mb-4  flex flex-col items-start justify-start">
                <label class="pl-2 pb-2 text-gray-500">Email (*)</label>
                <input wire:model="email"
                    class="py-1.5 px-4 w-full bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none"
                    type="text">
                <div class="text-red-500 text-sm mt-1">
                    @error('email')
                        {{ $message }}
                    @enderror
                </div>
            </div>

            {{--            <div class="w-full px-2 mb-4  flex flex-col items-start justify-start"> --}}
            {{--                <label class="pl-2 pb-2 text-gray-500">Mật khẩu (*)</label> --}}
            {{--                <div class="flex items-center relative w-full"> --}}
            {{--                    <input wire:model="password" --}}
            {{--                        class="py-1.5 px-4 w-full bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none" --}}
            {{--                        type="{{ $isShowPassword ? 'text' : 'password' }}"> --}}
            {{--                    @if ($isShowPassword) --}}
            {{--                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" --}}
            {{--                            stroke="currentColor" class="size-5 absolute right-5 cursor-pointer" --}}
            {{--                            wire:click="$toggle('isShowPassword')"> --}}
            {{--                            <path stroke-linecap="round" stroke-linejoin="round" --}}
            {{--                                d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /> --}}
            {{--                            <path stroke-linecap="round" stroke-linejoin="round" --}}
            {{--                                d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /> --}}
            {{--                        </svg> --}}
            {{--                    @else --}}
            {{--                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" --}}
            {{--                            stroke="currentColor" class="size-5 absolute right-5 cursor-pointer" --}}
            {{--                            wire:click="$toggle('isShowPassword')"> --}}
            {{--                            <path stroke-linecap="round" stroke-linejoin="round" --}}
            {{--                                d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" /> --}}
            {{--                        </svg> --}}
            {{--                    @endif --}}
            {{--                </div> --}}
            {{--                <div class="text-red-500 text-sm mt-1"> --}}
            {{--                    @error('password') --}}
            {{--                        {{ $message }} --}}
            {{--                    @enderror --}}
            {{--                </div> --}}
            {{--            </div> --}}
            {{--            <div class="w-full px-2 mb-4  flex flex-col items-start justify-start"> --}}
            {{--                <label class="pl-2 pb-2 text-gray-500">Nhập lại Mật khẩu (*)</label> --}}
            {{--                <div class="flex items-center relative w-full"> --}}
            {{--                    <input wire:model="password_confirmation" --}}
            {{--                        class="py-1.5 px-4 w-full bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none" --}}
            {{--                        type="{{ $isShowPasswordConfirmation ? 'text' : 'password' }}"> --}}
            {{--                    @if ($isShowPasswordConfirmation) --}}
            {{--                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" --}}
            {{--                            stroke="currentColor" class="size-5 absolute right-5 cursor-pointer" --}}
            {{--                            wire:click="$toggle('isShowPasswordConfirmation')"> --}}
            {{--                            <path stroke-linecap="round" stroke-linejoin="round" --}}
            {{--                                d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /> --}}
            {{--                            <path stroke-linecap="round" stroke-linejoin="round" --}}
            {{--                                d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /> --}}
            {{--                        </svg> --}}
            {{--                    @else --}}
            {{--                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" --}}
            {{--                            stroke="currentColor" class="size-5 absolute right-5 cursor-pointer" --}}
            {{--                            wire:click="$toggle('isShowPasswordConfirmation')"> --}}
            {{--                            <path stroke-linecap="round" stroke-linejoin="round" --}}
            {{--                                d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" /> --}}
            {{--                        </svg> --}}
            {{--                    @endif --}}
            {{--                </div> --}}
            {{--                <div class="text-red-500 text-sm mt-1"> --}}
            {{--                    @error('password') --}}
            {{--                        {{ $message }} --}}
            {{--                    @enderror --}}
            {{--                </div> --}}
            {{--            </div> --}}

            <div class="w-full px-2 mb-4 flex flex-col items-start justify-start">
                <label class="pl-2 pb-2 text-gray-500">Số điện thoại (*)</label>
                <input wire:model="phone"
                    class="py-1.5 px-4 w-full bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none"
                    type="text">
                <div class="text-red-500 text-sm mt-1">
                    @error('phone')
                        {{ $message }}
                    @enderror
                </div>
            </div>
            <div class="w-full px-2 mb-4 flex flex-col items-start justify-start">
                <label class="pl-2 pb-2 text-gray-500">Ngày sinh (*)</label>
                <input wire:model="birthday"
                    class="py-1.5 px-4 w-full bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none"
                    type="date">
                <div class="text-red-500 text-sm mt-1">
                    @error('birthday')
                        {{ $message }}
                    @enderror
                </div>
            </div>
            <div class="flex items-center col-span-2 mb-4">
                <label class="pl-5 text-gray-500 w-1/2 text-start">Giới tính (*)</label>
                <div class="w-1/2 pl-3">
                    <select id="location" name="location" class="py-1.5 bg-gray-200 rounded-md px-4"
                        wire:model="gender">
                        <option value="1" selected>Nam</option>
                        <option value="0">Nữ</option>
                    </select>
                    <div class="text-red-500 text-sm mt-1">
                        @error('gender')
                            {{ $message }}
                        @enderror
                    </div>
                </div>
            </div>
            <div class="flex items-center col-span-2 mb-4">
                <label class="pl-5 text-gray-500 w-1/2 text-start">Mã đăng ký (nếu có)</label>
                <div class="w-1/2 pl-3">
                    <input wire:model="code"
                        class="py-1.5 px-4 w-1/2 bg-gray-200 border focus:ring-2 focus:ring-opacity-90 focus:ring-indigo-500 border-gray-100 rounded-md focus:outline-none"
                        type="text">
                    <div class="text-red-500 text-sm mt-1">
                        @error('code')
                            {{ $message }}
                        @enderror
                    </div>
                </div>
            </div>
        </div>
        @if ($message)
            <div
                class="relative w-full rounded-lg border border-transparent bg-green-50 p-4 [&>svg]:absolute [&>svg]:text-foreground [&>svg]:left-4 [&>svg]:top-4 [&>svg+div]:translate-y-[-3px] [&:has(svg)]:pl-11 text-green-600">
                <svg class="w-5 h-5 -translate-y-0.5" xmlns="http://www.w3.org/2000/svg" fill="none"
                    viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div class="text-sm opacity-80">{{ $message }}</div>
            </div>
        @endif
        @if ($messageAfterValidation)
            <div
                class="relative w-full rounded-lg border border-transparent bg-red-50 p-4 [&>svg]:absolute [&>svg]:text-foreground [&>svg]:left-4 [&>svg]:top-4 [&>svg+div]:translate-y-[-3px] [&:has(svg)]:pl-11 text-red-600">
                <svg class="w-5 h-5 -translate-y-0.5" xmlns="http://www.w3.org/2000/svg" fill="none"
                    viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
                </svg>
                <div class="text-sm opacity-80">{{ $messageAfterValidation }}</div>
            </div>
        @endif
        <button class="flex w-fit px-6 py-2 mt-4 text-white rounded-xl bg-[#203354] mx-auto"
            wire:loading.class="disabled" wire:loading.class.remove="bg-[#203354]" wire:loading.attr="disabled">
            <div wire:loading>
                <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <style>
                        .spinner_EUy1 {
                            animation: spinner_grm3 1.2s infinite
                        }

                        .spinner_f6oS {
                            animation-delay: .1s
                        }

                        .spinner_g3nX {
                            animation-delay: .2s
                        }

                        .spinner_nvEs {
                            animation-delay: .3s
                        }

                        .spinner_MaNM {
                            animation-delay: .4s
                        }

                        .spinner_4nle {
                            animation-delay: .5s
                        }

                        .spinner_ZETM {
                            animation-delay: .6s
                        }

                        .spinner_HXuO {
                            animation-delay: .7s
                        }

                        .spinner_YaQo {
                            animation-delay: .8s
                        }

                        .spinner_GOx1 {
                            animation-delay: .9s
                        }

                        .spinner_4vv9 {
                            animation-delay: 1s
                        }

                        .spinner_NTs9 {
                            animation-delay: 1.1s
                        }

                        .spinner_auJJ {
                            transform-origin: center;
                            animation: spinner_T3O6 6s linear infinite
                        }

                        @keyframes spinner_grm3 {

                            0%,
                            50% {
                                animation-timing-function: cubic-bezier(.27, .42, .37, .99);
                                r: 1px
                            }

                            25% {
                                animation-timing-function: cubic-bezier(.53, 0, .61, .73);
                                r: 2px
                            }
                        }

                        @keyframes spinner_T3O6 {
                            0% {
                                transform: rotate(360deg)
                            }

                            100% {
                                transform: rotate(0deg)
                            }
                        }
                    </style>
                    <g class="spinner_auJJ">
                        <circle class="spinner_EUy1" cx="12" cy="3" r="1" />
                        <circle class="spinner_EUy1 spinner_f6oS" cx="16.50" cy="4.21" r="1" />
                        <circle class="spinner_EUy1 spinner_NTs9" cx="7.50" cy="4.21" r="1" />
                        <circle class="spinner_EUy1 spinner_g3nX" cx="19.79" cy="7.50" r="1" />
                        <circle class="spinner_EUy1 spinner_4vv9" cx="4.21" cy="7.50" r="1" />
                        <circle class="spinner_EUy1 spinner_nvEs" cx="21.00" cy="12.00" r="1" />
                        <circle class="spinner_EUy1 spinner_GOx1" cx="3.00" cy="12.00" r="1" />
                        <circle class="spinner_EUy1 spinner_MaNM" cx="19.79" cy="16.50" r="1" />
                        <circle class="spinner_EUy1 spinner_YaQo" cx="4.21" cy="16.50" r="1" />
                        <circle class="spinner_EUy1 spinner_4nle" cx="16.50" cy="19.79" r="1" />
                        <circle class="spinner_EUy1 spinner_HXuO" cx="7.50" cy="19.79" r="1" />
                        <circle class="spinner_EUy1 spinner_ZETM" cx="12" cy="21" r="1" />
                    </g>
                </svg>
            </div>
            <span wire:loading.class="hidden">ĐĂNG KÝ</span>
        </button>
    </form>
</section>
