<?php

use Spatie\LaravelSettings\Migrations\SettingsMigration;

return new class extends SettingsMigration
{
    public function up(): void
    {
        $this->migrator->add('register.domains');
        $this->migrator->add('register.haravanApiToken');
        $this->migrator->add('register.emailIsNotInOrg');
        $this->migrator->add('register.emailIsExists');
        $this->migrator->add('register.registerSuccess');
    }
};
