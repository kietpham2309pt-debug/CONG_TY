<?php

use Spatie\LaravelSettings\Migrations\SettingsMigration;

return new class extends SettingsMigration
{
    public function up(): void
    {
        $this->migrator->add('register.codes', []);
        $this->migrator->add('register.codeIsNotValid');
    }
};
