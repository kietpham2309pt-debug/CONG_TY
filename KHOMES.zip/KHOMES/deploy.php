<?php

namespace Deployer;

require 'recipe/laravel.php';

// Config

set('repository', 'git@github.com:xmannv/register-khomes.git');

add('shared_files', [
    'database/database.sqlite',
]);

add('shared_dirs', []);
add('writable_dirs', []);

// Hosts

host('103.20.96.229')
    ->set('remote_user', 'root')
    ->set('deploy_path', '/home/runcloud/webapps/register');

// Hooks

after('deploy:failed', 'deploy:unlock');

task('webserver', function () {
    //    invoke('artisan:optimize:clear');

    run('chown -R runcloud:runcloud /home/runcloud/webapps/register/releases/');
    run('chown -R runcloud:runcloud /home/runcloud/webapps/register/shared/');
    run('chown -R runcloud:runcloud /home/runcloud/webapps/register/current');
    run('systemctl restart php83rc-fpm');
    //    invoke('artisan:horizon:terminate');
})->desc('Restart PHP-FPM service');

task('updateVendors', function () {
    run('cd {{release_or_current_path}} && {{bin/composer}} update {{composer_options}} 2>&1');
    run('cd {{release_or_current_path}} && npm install && npm run build 2>&1');
})->desc('Update Composer packages');

after('deploy:success', 'webserver');
after('deploy:vendors', 'updateVendors');
